return 
{
	{"nvim-treesitter/nvim-treesitter", build= ":TSUpdate"  { "lervag/vimtex", lazy = false   { "L3MON4D3/LuaSnip", version = "v2.*", build = "make install_jsregexp"   { "rafamadriz/friendly-snippets"   { "micangl/cmp-vimtex"   { "windwp/nvim-autopairs", config = function() require("nvim-autopairs").setup() end },
},
},
},
},
},
	{"nvim-neo-tree/neo-tree.nvim",
		branch = "v3.x",
		dependencies = {
		"nvim-lua/plenary.nvim",
		"nvim-tree/nvim-web-devicons",
		"MunifTanjim/nui.nvim",
	}
  }
  }

